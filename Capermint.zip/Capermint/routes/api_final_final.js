const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const auth = require('../middleware/auth'); // Importing the auth middleware

// User registration
router.post('/register', async (req, res) => {
    const { name, email, phone, password } = req.body;

    // Check if the email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
        return res.status(400).json({ message: 'Email already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ name, email, phone, password: hashedPassword });
    await user.save();
    res.status(201).json({ message: 'User registered successfully' });
});

// User login
router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (user && await bcrypt.compare(password, user.password)) {
        const token = jwt.sign({ id: user._id }, 'your_jwt_secret');
        res.json({ token, message: 'Login successful' }); // Return token and message
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

// View profile
router.get('/profile', auth, async (req, res) => { // Applying auth middleware
    const userId = req.user.id;
    const user = await User.findById(userId);
    res.render('profile', { user }); // Render the profile view with user data
});

// Update profile
router.put('/profile', auth, async (req, res) => { // Applying auth middleware
    const userId = req.user.id;
    const { name, email, phone, password } = req.body;
    const updatedData = { name, email, phone };
    if (password) {
        updatedData.password = await bcrypt.hash(password, 10);
    }
    await User.findByIdAndUpdate(userId, updatedData);
    res.json({ message: 'Profile updated successfully' });
});

module.exports = router;
