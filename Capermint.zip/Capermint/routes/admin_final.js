const express = require('express');
const router = express.Router();
const Category = require('../models/Category');
const Product = require('../models/Product');

// Admin login route
router.get('/login', (req, res) => {
    res.render('admin'); // Render the admin login view
});

// Admin products management route
router.get('/products', (req, res) => {
    res.render('products'); // Render the products management view
});

// Admin categories management route
router.get('/categories', (req, res) => {
    res.render('categories'); // Render the categories management view
});

// Admin login
router.post('/login', (req, res) => {
    // Admin login logic here
});

// Category management
router.post('/categories', async (req, res) => {
    const { name, parent } = req.body;
    const category = new Category({ name, parent });
    await category.save();
    res.status(201).json({ message: 'Category created successfully' });
});

// Product management
router.post('/products', async (req, res) => {
    const { image, title, category, description, amount } = req.body;
    const product = new Product({ image, title, category, description, amount });
    await product.save();
    res.status(201).json({ message: 'Product created successfully' });
});

module.exports = router;
